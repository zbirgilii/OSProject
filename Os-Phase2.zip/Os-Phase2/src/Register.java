
class Register {
    int data = 0;
}
